# MySQL-python
### parsing data from csv file to sql database

## Requirements
* MySQL database 
* install mysql connector library: [mysql-connector-python](https://pypi.org/project/mysql-connector-python/)

 
